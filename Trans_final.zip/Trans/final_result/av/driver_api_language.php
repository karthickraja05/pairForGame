<?php
return
[
"gofereats" => [
"todays_trips" => "Today's Trips",
"past_trips" => "Past Trips",
"completed" => "Completed",
"end_trip" => "End Trip",
"begin_trip" => "Begin Trip",
"cancelled" => "Cancelled",
"request" => "Request",
"pending" => "Pending",
"scheduled" => "Scheduled",
],

]