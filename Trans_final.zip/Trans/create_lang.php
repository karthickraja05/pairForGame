<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
	<?php

	include('trans.php');

	$data = $_POST['lang'];

	if(count($data)){
		foreach ($data as  $value) {
			$obj = new LangCreator('en',$value);
			$obj->creator();
			
		}
	}

	echo 'Created Successfully';

	?>

	<a href="index.php"><button>Back</button></a>

</body>
</html>