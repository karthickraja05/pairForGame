<?php

return 
[
	'name' => 'name',
	'language' => 'language',
	'select_language' => 'Select Language',
	'description' => 'Description',
	'item_name' => 'item name',
	'category_name' => 'category name',
	'profile'=>
	[
		'support' => 'Support',
		'login_failed' => 'Login Failed',
		'sign_in' => 'Sign In',
		'register' => 'Register',
	],
];