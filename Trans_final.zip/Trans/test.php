<?php 

include('trans.php');

$obj = new LangCreator('en','ta');
// $obj->creator();
echo $obj->transLate('welcome');